const status = document.getElementById('status');
let startScanInProgress = false;

document.getElementById('startBtn').onclick = () => {
  chrome.runtime.sendMessage({ action: 'START' });
  startScanInProgress = true;
  updateUI(true, startScanInProgress);
  //status.innerText = 'Running';
};

document.getElementById('stopBtn').onclick = () => {
  chrome.runtime.sendMessage({ action: 'STOP' });
  //status.innerText = 'Stopped';
  startScanInProgress = false;
  updateUI(false, startScanInProgress);
};


document.getElementById("scanBtn").addEventListener("click", () => {
  console.log("[POPUP][TIMING] Scan Current Page clicked", Date.now());
  chrome.runtime.sendMessage({ action: "SCAN_CURRENT_PAGE" });
});

function loadReportSettings() {
  chrome.storage.local.get("reportSettings", (data) => {
    const settings = Object.assign(
      { showDebugDetails: true, showNormalizedOutput: true },
      data.reportSettings || {}
    );
    document.getElementById("showDebugDetails").checked =
      settings.showDebugDetails !== false;
    document.getElementById("showNormalizedOutput").checked =
      settings.showNormalizedOutput !== false;
  });
}

function saveReportSettings() {
  const settings = {
    showDebugDetails: document.getElementById("showDebugDetails").checked,
    showNormalizedOutput: document.getElementById("showNormalizedOutput").checked
  };
  chrome.storage.local.set({ reportSettings: settings });
}

document
  .getElementById("showDebugDetails")
  .addEventListener("change", saveReportSettings);
document
  .getElementById("showNormalizedOutput")
  .addEventListener("change", saveReportSettings);

/*document.getElementById('scanBtn').onclick = () => {
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    chrome.tabs.sendMessage(tabs[0].id, { action: 'SCAN_CURRENT_PAGE' }, result => {
      console.log('Scan result:', result);
    });
  });
};*/

document.addEventListener("DOMContentLoaded", () => {
  const version = chrome.runtime.getManifest().version;
  document.getElementById("extVersion").textContent = version;
  chrome.storage.local.get("scanState", (data) => {
    const isActive = data.scanState?.active === true;
    startScanInProgress = data.scanState?.startScanInProgress === true;
    updateUI(isActive, startScanInProgress);
  });
  loadReportSettings();
});

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "START_SCAN_COMPLETED" || message?.type === "START_SCAN_TIMEOUT") {
    startScanInProgress = false;
    chrome.storage.local.get("scanState", (data) => {
      const isActive = data.scanState?.active === true;
      updateUI(isActive, startScanInProgress);
    });
  }
});

function updateUI(isActive, scanInProgress = false) {
  const statusText = document.getElementById("statusText");
  const startBtn = document.getElementById("startBtn");
  const stopBtn = document.getElementById("stopBtn");
  const scanBtn = document.getElementById("scanBtn");

  if (isActive) {
    statusText.textContent = "Scanning started";
    startBtn.textContent = "Scanning Started";
    startBtn.disabled = true;
    startBtn.style.opacity = "0.6";
    stopBtn.disabled = scanInProgress;
    scanBtn.disabled = true;
  } else {
    statusText.textContent = "Ready";
    startBtn.textContent = "Start Scanning";
    startBtn.disabled = false;
    startBtn.style.opacity = "1";
    stopBtn.disabled = true;
    scanBtn.disabled = false;
  }
}

