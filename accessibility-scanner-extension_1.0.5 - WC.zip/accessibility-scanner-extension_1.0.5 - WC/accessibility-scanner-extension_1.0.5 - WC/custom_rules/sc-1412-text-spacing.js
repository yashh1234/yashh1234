/**
 * SC 1.4.12 Text Spacing
 * Automatable subset: Detect text elements with fixed height/max-height or
 * fixed width/max-width plus overflow hidden/clip that clip when user spacing
 * values are applied.
 * Limitations:
 * - Cannot verify paragraph spacing changes between elements.
 * - Cannot verify all user stylesheet override behaviors.
 * Version: 1.0
 * Author: Vijay Gupta  
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-1412-text-spacing";
  const CHECK_ID = "sc-1412-text-spacing-no-clipping";

  function hasMeaningfulText(node) {
    const text = (node.textContent || "").replace(/\s+/g, " ").trim();
    return text.length > 0;
  }

  function isVisible(style) {
    if (!style) return false;
    if (style.display === "none") return false;
    if (style.visibility === "hidden") return false;
    return true;
  }

  function isFixedSize(value) {
    if (!value) return false;
    if (value === "auto" || value === "none") return false;
    const num = parseFloat(value);
    return Number.isFinite(num);
  }

  function clipsOverflow(value) {
    return value === "hidden" || value === "clip";
  }

  function measureClipping(node, clipX, clipY) {
    let clippedY = false;
    let clippedX = false;

    if (clipY) {
      clippedY = node.scrollHeight - node.clientHeight > 1;
    }
    if (clipX) {
      clippedX = node.scrollWidth - node.clientWidth > 1;
    }

    const metrics = {
      scrollHeight: node.scrollHeight,
      clientHeight: node.clientHeight,
      scrollWidth: node.scrollWidth,
      clientWidth: node.clientWidth
    };

    return {
      clipped: clippedY || clippedX,
      clippedX,
      clippedY,
      metrics
    };
  }

  function checkClippingAfterSpacing(node, clipX, clipY) {
    const original = {
      lineHeight: node.style.lineHeight,
      letterSpacing: node.style.letterSpacing,
      wordSpacing: node.style.wordSpacing
    };

    node.style.lineHeight = "1.5";
    node.style.letterSpacing = "0.12em";
    node.style.wordSpacing = "0.16em";

    const result = measureClipping(node, clipX, clipY);

    node.style.lineHeight = original.lineHeight;
    node.style.letterSpacing = original.letterSpacing;
    node.style.wordSpacing = original.wordSpacing;

    return {
      ...result,
      spacingApplied: {
        lineHeight: "1.5",
        letterSpacing: "0.12em",
        wordSpacing: "0.16em"
      }
    };
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        //selector: "*",
        selector: "p, h1, h2, h3, h4, h5, h6, li, blockquote, span, a, strong, em, b, i, code, kbd, samp, label, button, input[type='text'], textarea, select, option, caption, th, td, legend, figcaption, div, span",
        impact: "moderate",
        tags: ["wcag2aa", "wcag22aa", "wcag1412", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Text containers should not clip content when WCAG text spacing values are applied",
          help:
            "Ensure fixed-size text containers with overflow clipping still show content when line-height, letter-spacing, and word-spacing are increased",
          helpUrl: "https://www.w3.org/TR/WCAG22/#text-spacing",
          messages: {
            pass: "1.4.12 - Text Spacing - Pass",
            fail: "1.4.12 - Text Spacing - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          const style = window.getComputedStyle(node);

          //Skip elements that are hidden, inline, or contain no meaningful text
          if (!isVisible(style)) return true;
          if (style.display === "inline") return true;
          if (!hasMeaningfulText(node)) return true;


          //extracting overflow property
          const overflowX = style.overflowX || style.overflow;
          const overflowY = style.overflowY || style.overflow;

          //evaluate if overflow is hidden/clip.
          const clipX = clipsOverflow(overflowX);
          const clipY = clipsOverflow(overflowY);

          //evaluate if elements have fixed height and width
          const fixedHeight =
            isFixedSize(style.height) || isFixedSize(style.maxHeight);
          const fixedWidth =
            isFixedSize(style.width) || isFixedSize(style.maxWidth);

          const shouldCheckY = clipY && fixedHeight;
          const shouldCheckX = clipX && fixedWidth;

          //Only evaluate elements with fixed size and overflow hidden/clip.
          if (!shouldCheckY && !shouldCheckX) return true;

          const styleSnapshot = {
            display: style.display,
            overflowX: overflowX || "",
            overflowY: overflowY || "",
            width: style.width,
            maxWidth: style.maxWidth,
            height: style.height,
            maxHeight: style.maxHeight
          };

          const baseline = measureClipping(node, shouldCheckX, shouldCheckY);
          if (baseline.clipped) return true;

          const result = checkClippingAfterSpacing(node, shouldCheckX, shouldCheckY);
          if (!result.clipped) return true;

          const axis =
            result.clippedX && result.clippedY
              ? "horizontally and vertically"
              : result.clippedX
              ? "horizontally"
              : "vertically";
          const size =
            fixedWidth && fixedHeight
              ? "fixed width/height"
              : fixedWidth
              ? "fixed width"
              : "fixed height";

          this.data = {
            reason: `Text becomes larger than the visible area after spacing is increased, so it gets cut off ${axis} (${size} with overflow hidden/clip).`,
            clipX: shouldCheckX,
            clipY: shouldCheckY,
            fixedWidth,
            fixedHeight,
            style: styleSnapshot,
            metrics: result.metrics,
            baselineMetrics: baseline.metrics,
            baselineClipping: {
              clippedX: baseline.clippedX,
              clippedY: baseline.clippedY
            },
            clipping: {
              clippedX: result.clippedX,
              clippedY: result.clippedY
            },
            spacingApplied: result.spacingApplied,
          };

          return false;
        },
        metadata: {
          impact: "moderate",
          messages: {
            pass:
              "1.4.12 - Text Spacing - no clipping after spacing adjustments - Pass",
            fail:
              "1.4.12 - Text Spacing - clipped content after spacing adjustments - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-1412-text-spacing loaded");
})();
