/**
 * SC 1.4.10 Reflow
 * Automatable subset: Flag visible non-inline elements (excluding known
 * two-dimensional content) that set min-width greater than 320px or an
 * explicit inline width greater than 320px.
 * Limitations:
 * - Does not measure actual horizontal scrolling or layout at 320px.
 * - Does not evaluate reflow failures caused by fixed widths, positioning,
 *   or long unbreakable strings.
 * - Only checks inline width styles, not class-based CSS widths.
 * Version: 1.0
 * Author: Vijay Gupta  
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-1410-reflow";
  const CHECK_ID = "sc-1410-reflow-min-width-over-320";
  const MAX_REFLOW_WIDTH = 426;

  const EXCEPTION_TAGS = new Set([
    "IMG",
    "SVG",
    "CANVAS",
    "VIDEO",
    "IFRAME",
    "OBJECT",
    "EMBED",
    "TABLE"
  ]);

  function isVisible(style) {
    if (!style) return false;
    if (style.display === "none") return false;
    if (style.visibility === "hidden") return false;
    return true;
  }

  function isInline(style) {
    return style && style.display === "inline";
  }

  function parsePx(value) {
    if (!value) return null;
    if (value === "auto") return null;
    const num = parseFloat(value);
    return Number.isFinite(num) ? num : null;
  }

  function getOverflowValue(style, axis) {
    if (!style) return "";
    const value = axis === "x"
      ? (style.overflowX || style.overflow || "")
      : (style.overflowY || style.overflow || "");
    return String(value).toLowerCase();
  }

  function clipsOverflow(style) {
    const overflowX = getOverflowValue(style, "x");
    const overflowY = getOverflowValue(style, "y");
    return {
      overflowX,
      overflowY,
      clipX: overflowX === "hidden" || overflowX === "clip",
      clipY: overflowY === "hidden" || overflowY === "clip"
    };
  }

  function getSamplePoints(rect) {
    const inset = 2;
    return [
      { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 },
      { x: rect.left + inset, y: rect.top + inset },
      { x: rect.right - inset, y: rect.top + inset },
      { x: rect.left + inset, y: rect.bottom - inset },
      { x: rect.right - inset, y: rect.bottom - inset }
    ];
  }

  function isElementOnTop(node, point) {
    const top = document.elementFromPoint(point.x, point.y);
    if (!top) return false;
    return top === node || node.contains(top);
  }

  function getInlineWidthPx(node) {
    if (!node || !node.style) return null;
    const raw = node.style.width;
    if (!raw || !raw.endsWith("px")) return null;
    return parsePx(raw);
  }

  function isExceptionTag(node) {
    return EXCEPTION_TAGS.has(node.tagName);
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        //selector: "*",
        selector: "div, section, article, aside, main, header, footer, p, h1, h2, h3, h4, h5, h6, li, blockquote, span, a, strong, em, b, i, img, svg, video, canvas, table, th, td, caption, form, label, input, textarea, select, option, button, nav, ul, ol",
        impact: "serious",
        tags: ["wcag2aa", "wcag22aa", "wcag1410", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "Content should reflow at 320 CSS pixels without horizontal scrolling",
          help:
            "Ensure containers do not enforce min-width or inline width greater than 320px (except for two-dimensional content)",
          helpUrl: "https://www.w3.org/TR/WCAG22/#reflow",
          messages: {
            pass: "1.4.10 - Reflow - Pass",
            fail: "1.4.10 - Reflow - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        evaluate: function (node) {
          const style = window.getComputedStyle(node);

          if (!isVisible(style)) return true;
          if (isInline(style)) return true;
          if (isExceptionTag(node)) return true;

          const rect = node.getBoundingClientRect();
          if (!rect || rect.width <= 0 || rect.height <= 0) return true;

          const minWidth = parsePx(style.minWidth);
          const inlineWidth = getInlineWidthPx(node);
          const hasInlineWidthViolation =
            inlineWidth !== null && inlineWidth > MAX_REFLOW_WIDTH;
          const hasMinWidthViolation =
            minWidth !== null && minWidth > MAX_REFLOW_WIDTH;

          if (!hasInlineWidthViolation && !hasMinWidthViolation) return true;

          const overflow = clipsOverflow(style);
          const clippedX = overflow.clipX && node.scrollWidth > node.clientWidth;
          const clippedY = overflow.clipY && node.scrollHeight > node.clientHeight;

          const reasons = [];
          if (clippedX || clippedY) {
            if (hasInlineWidthViolation) {
              reasons.push(`inline width ${inlineWidth}px > ${MAX_REFLOW_WIDTH}px`);
            }
            if (hasMinWidthViolation) {
              reasons.push(`min-width ${minWidth}px > ${MAX_REFLOW_WIDTH}px`);
            }

            this.data = {
              reason: `Element exceeds reflow width and clips content: ${reasons.join(" and ")}.`,
              minWidth,
              inlineWidth,
              limit: MAX_REFLOW_WIDTH,
              outcome: "fail",
              clipX: overflow.clipX,
              clipY: overflow.clipY,
              metrics: {
                scrollWidth: node.scrollWidth,
                clientWidth: node.clientWidth,
                scrollHeight: node.scrollHeight,
                clientHeight: node.clientHeight
              },
              style: {
                display: style.display,
                minWidth: style.minWidth,
                width: style.width,
                overflowX: overflow.overflowX,
                overflowY: overflow.overflowY
              }
            };

            return false;
          }

          const offscreenRisk =
            rect.left < 0 ||
            rect.right > MAX_REFLOW_WIDTH ||
            rect.width > MAX_REFLOW_WIDTH;
          if (offscreenRisk) {
            this.data = {
              reason: "Element exceeds reflow width and may extend off-screen at 320px/400% zoom.",
              minWidth,
              inlineWidth,
              limit: MAX_REFLOW_WIDTH,
              outcome: "incomplete",
              riskType: "OFFSCREEN_RISK",
              boundingBox: {
                left: rect.left,
                right: rect.right,
                top: rect.top,
                bottom: rect.bottom,
                width: rect.width,
                height: rect.height
              }
            };
            return undefined;
          }

          const points = getSamplePoints(rect);
          let visibleCount = 0;
          points.forEach((point) => {
            if (isElementOnTop(node, point)) visibleCount += 1;
          });
          if (visibleCount === 0) {
            this.data = {
              reason: "Element exceeds reflow width and appears overlapped.",
              minWidth,
              inlineWidth,
              limit: MAX_REFLOW_WIDTH,
              outcome: "incomplete",
              riskType: "OVERLAP_RISK",
              samplePoints: points.map((point) => ({
                x: Math.round(point.x),
                y: Math.round(point.y)
              }))
            };
            return undefined;
          }

          return true;
        },
        metadata: {
          impact: "serious",
          messages: {
            pass:
              "1.4.10 - Reflow - min-width or inline width at or below 320px - Pass",
            fail:
              "1.4.10 - Reflow - min-width or inline width greater than 320px - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-1410-reflow loaded");
})();
