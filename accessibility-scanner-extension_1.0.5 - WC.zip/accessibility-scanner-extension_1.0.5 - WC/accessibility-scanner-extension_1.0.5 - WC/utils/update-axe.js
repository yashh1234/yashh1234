const fs = require("fs");
const path = require("path");

const src = path.join(__dirname, "..", "node_modules", "axe-core", "axe.min.js");
const dest = path.join(__dirname, "..", "lib", "axe-core", "axe.min.js");

if (!fs.existsSync(src)) {
  console.error("axe-core not installed. Run npm install first.");
  process.exit(1);
}

fs.copyFileSync(src, dest);
console.log("Updated lib/axe-core/axe.min.js from node_modules/axe-core/axe.min.js");
