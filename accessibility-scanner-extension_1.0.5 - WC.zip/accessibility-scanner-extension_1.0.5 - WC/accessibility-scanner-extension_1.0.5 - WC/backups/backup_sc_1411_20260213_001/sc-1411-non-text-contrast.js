/**
 * SC 1.4.11 Non-text Contrast (Conservative)
 * Automatable subset: Visible UI components (native form controls + common ARIA roles)
 * with a discernible outline, border, or solid background must have >= 3:1 contrast
 * against the computed effective background.
 *
 * Accuracy-first: Prefer skipping uncertain cases over false positives.
 * Limitations:
 * - Ignores gradients and background images.
 * - Does not evaluate complex graphics or icons.
 * - Focus-visible styles are only tested when programmatically triggerable.
 *
 * Version: 2.0
 * Author: Vijay Gupta
 */
(function () {
  const RULE_ID = "custom-wcag22-sc-1411-non-text-contrast";
  const CHECK_ID = "sc-1411-non-text-contrast-min-3";
  const DEFAULT_MIN_CONTRAST = 3;

  const CONTROL_SELECTOR = [
    "button",
    "input",
    "select",
    "textarea",
    "[role=\"button\"]",
    "[role=\"checkbox\"]",
    "[role=\"radio\"]",
    "[role=\"switch\"]",
    "[role=\"combobox\"]",
    "[role=\"listbox\"]",
    "[role=\"slider\"]",
    "[role=\"spinbutton\"]",
    "[role=\"textbox\"]"
  ].join(", ");

  function parseColor(value) {
    if (!value) return null;
    const normalized = String(value).trim().toLowerCase();
    if (
      normalized === "transparent" ||
      normalized === "initial" ||
      normalized === "unset"
    ) {
      return { r: 0, g: 0, b: 0, a: 0 };
    }

    const match = normalized.match(/rgba?\(([^)]+)\)/);
    if (!match) return null;

    const parts = match[1].split(",").map((part) => part.trim());
    if (parts.length < 3) return null;

    const r = parseFloat(parts[0]);
    const g = parseFloat(parts[1]);
    const b = parseFloat(parts[2]);
    const a = parts.length >= 4 ? parseFloat(parts[3]) : 1;

    if (![r, g, b, a].every((n) => Number.isFinite(n))) return null;

    return {
      r: Math.min(255, Math.max(0, r)),
      g: Math.min(255, Math.max(0, g)),
      b: Math.min(255, Math.max(0, b)),
      a: Math.min(1, Math.max(0, a))
    };
  }

  function toRgbaString(color) {
    if (!color) return "";
    const r = Math.round(color.r);
    const g = Math.round(color.g);
    const b = Math.round(color.b);
    const a = Number.isFinite(color.a) ? Number(color.a.toFixed(3)) : 1;
    return `rgba(${r}, ${g}, ${b}, ${a})`;
  }

  function alphaComposite(foreground, background) {
    const fgA = foreground.a;
    const bgA = background.a;
    const outA = fgA + bgA * (1 - fgA);

    if (outA === 0) {
      return { r: 0, g: 0, b: 0, a: 0 };
    }

    return {
      r: (foreground.r * fgA + background.r * bgA * (1 - fgA)) / outA,
      g: (foreground.g * fgA + background.g * bgA * (1 - fgA)) / outA,
      b: (foreground.b * fgA + background.b * bgA * (1 - fgA)) / outA,
      a: outA
    };
  }

  function srgbToLinear(channel) {
    const value = channel / 255;
    return value <= 0.03928
      ? value / 12.92
      : Math.pow((value + 0.055) / 1.055, 2.4);
  }

  function relativeLuminance(color) {
    return (
      0.2126 * srgbToLinear(color.r) +
      0.7152 * srgbToLinear(color.g) +
      0.0722 * srgbToLinear(color.b)
    );
  }

  function contrastRatio(colorA, colorB) {
    if (!colorA || !colorB) return null;
    const lumA = relativeLuminance(colorA);
    const lumB = relativeLuminance(colorB);
    const light = Math.max(lumA, lumB);
    const dark = Math.min(lumA, lumB);
    return (light + 0.05) / (dark + 0.05);
  }

  function getViewportBackground() {
    const htmlStyle = window.getComputedStyle(document.documentElement);
    const bodyStyle = window.getComputedStyle(document.body);
    const htmlBg = parseColor(htmlStyle.backgroundColor);
    const bodyBg = parseColor(bodyStyle.backgroundColor);

    if (bodyBg && bodyBg.a > 0) return bodyBg;
    if (htmlBg && htmlBg.a > 0) return htmlBg;

    return { r: 255, g: 255, b: 255, a: 1 };
  }

  function getEffectiveBackground(element) {
    const stack = [];
    let blended = { r: 0, g: 0, b: 0, a: 0 };
    let current = element;

    while (current && current.nodeType === 1) {
      const style = window.getComputedStyle(current);
      const color = parseColor(style.backgroundColor);
      if (color) {
        stack.push({
          tag: current.tagName.toLowerCase(),
          color: toRgbaString(color),
          alpha: color.a
        });
      }

      if (color && color.a > 0) {
        blended = alphaComposite(color, blended);
        if (color.a === 1) break;
      }
      current = current.parentElement;
    }

    if (blended.a === 0) {
      const viewportBg = getViewportBackground();
      blended = alphaComposite(viewportBg, blended);
    }

    if (blended.a === 0) {
      blended = { r: 255, g: 255, b: 255, a: 1 };
    }

    return { blendedBackground: blended, backgroundStack: stack };
  }

  function isVisible(style, rect) {
    if (!style) return false;
    if (style.display === "none") return false;
    if (style.visibility === "hidden") return false;
    if (parseFloat(style.opacity) === 0) return false;
    if (!rect) return true;
    if (rect.width <= 0 || rect.height <= 0) return false;
    return true;
  }

  function isOutlineVisible(style) {
    if (!style) return false;
    const width = parseFloat(style.outlineWidth || "0");
    if (width <= 0) return false;

    const outlineStyle = String(style.outlineStyle || "").toLowerCase();
    if (outlineStyle === "none" || outlineStyle === "hidden") return false;

    if (outlineStyle === "auto") return true;

    const color = parseColor(style.outlineColor);
    return !!(color && color.a > 0);
  }

  function getOutlineColor(style) {
    const color = parseColor(style.outlineColor);
    if (!color || color.a === 0) return null;
    return color;
  }

  function isBorderVisible(style) {
    if (!style) return false;
    const widths = [
      style.borderTopWidth,
      style.borderRightWidth,
      style.borderBottomWidth,
      style.borderLeftWidth
    ].map((value) => parseFloat(value || "0"));

    const styles = [
      style.borderTopStyle,
      style.borderRightStyle,
      style.borderBottomStyle,
      style.borderLeftStyle
    ].map((value) => String(value || "").toLowerCase());

    const colors = [
      style.borderTopColor,
      style.borderRightColor,
      style.borderBottomColor,
      style.borderLeftColor
    ].map(parseColor);

    for (let i = 0; i < widths.length; i += 1) {
      if (widths[i] <= 0) continue;
      if (styles[i] === "none" || styles[i] === "hidden") continue;
      if (!colors[i] || colors[i].a === 0) continue;
      return true;
    }

    return false;
  }

  function getBorderColor(style) {
    const sides = [
      { width: style.borderTopWidth, style: style.borderTopStyle, color: style.borderTopColor },
      { width: style.borderRightWidth, style: style.borderRightStyle, color: style.borderRightColor },
      { width: style.borderBottomWidth, style: style.borderBottomStyle, color: style.borderBottomColor },
      { width: style.borderLeftWidth, style: style.borderLeftStyle, color: style.borderLeftColor }
    ];

    for (const side of sides) {
      const width = parseFloat(side.width || "0");
      const sideStyle = String(side.style || "").toLowerCase();
      const color = parseColor(side.color);
      if (width <= 0) continue;
      if (sideStyle === "none" || sideStyle === "hidden") continue;
      if (!color || color.a === 0) continue;
      return color;
    }

    return null;
  }

  function getBackgroundColor(style) {
    const color = parseColor(style.backgroundColor);
    return color || null;
  }

  function hasNonTextDescendants(node) {
    if (!node || typeof node.querySelector !== "function") return false;
    return Boolean(node.querySelector("img, svg, canvas, video"));
  }

  function isFocusable(node) {
    if (!node || node.disabled) return false;

    const tag = String(node.tagName || "").toUpperCase();
    if (tag === "A") return node.hasAttribute("href");
    if (["BUTTON", "INPUT", "SELECT", "TEXTAREA"].includes(tag)) return true;

    const tabindex = node.getAttribute("tabindex");
    if (tabindex !== null) return parseInt(tabindex, 10) >= 0;

    if (node.hasAttribute("contenteditable")) {
      return node.getAttribute("contenteditable") !== "false";
    }

    return false;
  }

  function buildTesterDebug(stateResult, minContrast) {
    const boundaryLuminance = relativeLuminance(stateResult.boundaryColor);
    const backgroundLuminance = relativeLuminance(stateResult.backgroundColor);
    const ratio = stateResult.ratio;

    return {
      element: stateResult.selector,
      state: stateResult.state,
      decision: {
        rule: "WCAG 2.2 SC 1.4.11",
        result: stateResult.pass ? "PASS" : "FAIL",
        reason: stateResult.pass
          ? `Boundary contrast >= ${minContrast}:1`
          : `Boundary contrast < ${minContrast}:1`
      },
      boundary: {
        type: stateResult.boundaryType,
        visibleColor: toRgbaString(stateResult.boundaryColor),
        luminance: Number(boundaryLuminance.toFixed(4))
      },
      background: {
        visibleColor: toRgbaString(stateResult.backgroundColor),
        luminance: Number(backgroundLuminance.toFixed(4))
      },
      contrastCalculation: {
        formula: "(lighter + 0.05) / (darker + 0.05)",
        substitutedFormula: ratio !== null
          ? `(${Math.max(boundaryLuminance, backgroundLuminance).toFixed(4)} + 0.05) / (${Math.min(boundaryLuminance, backgroundLuminance).toFixed(4)} + 0.05) = ${ratio.toFixed(2)}`
          : "n/a",
        ratio: ratio !== null ? Number(ratio.toFixed(2)) : null,
        requiredMinimum: minContrast
      },
      testerInstructions: [
        "Inspect the element in browser devtools.",
        "Confirm the boundary matches the visible edge.",
        "Enter the two RGBA colors into a WCAG checker.",
        "Verify the ratio matches the reported value.",
        `Compare against ${minContrast} to confirm PASS/FAIL.`
      ]
    };
  }

  function buildEngineDebug(stateResult, backgroundStack, compositingSteps) {
    return {
      status: stateResult.pass ? "PASS" : "FAIL",
      boundaryRawColor: toRgbaString(stateResult.boundaryColor),
      boundaryEffectiveColor: toRgbaString(stateResult.effectiveComponentColor),
      effectiveComponentColor: toRgbaString(stateResult.effectiveComponentColor),
      blendedBackground: toRgbaString(stateResult.backgroundColor),
      backgroundStack,
      styleSnapshot: stateResult.styleSnapshot,
      alphaCompositingSteps: compositingSteps
    };
  }

  function evaluateState(node, stateLabel, minContrast) {
    const style = window.getComputedStyle(node);
    const rect = node.getBoundingClientRect();

    if (!isVisible(style, rect)) {
      return { skipped: true, reason: "not-visible", state: stateLabel };
    }

    if (node.tagName === "INPUT" && node.type === "hidden") {
      return { skipped: true, reason: "hidden-input", state: stateLabel };
    }

    const backgroundInfo = getEffectiveBackground(node.parentElement);
    const blendedBackground = backgroundInfo.blendedBackground;

    const styleSnapshot = {
      display: style.display,
      visibility: style.visibility,
      opacity: style.opacity,
      outlineWidth: style.outlineWidth,
      outlineStyle: style.outlineStyle,
      outlineColor: style.outlineColor,
      borderTopWidth: style.borderTopWidth,
      borderTopStyle: style.borderTopStyle,
      borderTopColor: style.borderTopColor,
      borderRightWidth: style.borderRightWidth,
      borderRightStyle: style.borderRightStyle,
      borderRightColor: style.borderRightColor,
      borderBottomWidth: style.borderBottomWidth,
      borderBottomStyle: style.borderBottomStyle,
      borderBottomColor: style.borderBottomColor,
      borderLeftWidth: style.borderLeftWidth,
      borderLeftStyle: style.borderLeftStyle,
      borderLeftColor: style.borderLeftColor,
      backgroundColor: style.backgroundColor,
      backgroundImage: style.backgroundImage
    };

    let boundaryType = "background";
    let boundaryColor = null;

    const outlineVisible = isOutlineVisible(style);
    const borderVisible = isBorderVisible(style);

    if (outlineVisible) {
      boundaryType = "outline";
      boundaryColor = getOutlineColor(style);
      if (!boundaryColor) {
        return { skipped: true, reason: "outline-color-unknown", state: stateLabel };
      }
    } else if (borderVisible) {
      boundaryType = "border";
      boundaryColor = getBorderColor(style);
      if (!boundaryColor) {
        return { skipped: true, reason: "border-color-unknown", state: stateLabel };
      }
    } else {
      // Text-only controls (no outline/border/background/icon) are skipped to avoid false positives.
      const backgroundColor = getBackgroundColor(style);
      const backgroundAlpha = backgroundColor ? backgroundColor.a : 0;
      const hasBackgroundImage =
        style.backgroundImage && style.backgroundImage !== "none";
      const hasTextContent = Boolean((node.textContent || "").trim());
      const hasNonText = hasNonTextDescendants(node);
      if (!hasBackgroundImage && backgroundAlpha === 0 && hasTextContent && !hasNonText) {
        return { skipped: true, reason: "text-only-control", state: stateLabel };
      }

      if (style.backgroundImage && style.backgroundImage !== "none") {
        return { skipped: true, reason: "background-image", state: stateLabel };
      }

      boundaryType = "background";
      boundaryColor = backgroundColor;
      if (!boundaryColor) {
        boundaryColor = { r: 0, g: 0, b: 0, a: 0 };
      }

      if (boundaryColor.a === 0) {
        boundaryColor = blendedBackground;
      }
    }

    const compositingSteps = [];
    compositingSteps.push({
      step: "boundary over background",
      foreground: toRgbaString(boundaryColor),
      background: toRgbaString(blendedBackground)
    });

    const effectiveComponentColor = alphaComposite(boundaryColor, blendedBackground);
    const ratio = contrastRatio(effectiveComponentColor, blendedBackground);
    const pass = ratio !== null && ratio >= minContrast;

    return {
      state: stateLabel,
      pass,
      ratio,
      boundaryType,
      boundaryColor,
      backgroundColor: blendedBackground,
      effectiveComponentColor,
      backgroundStack: backgroundInfo.backgroundStack,
      compositingSteps,
      styleSnapshot
    };
  }

  function getStableSelector(node) {
    if (node.id) return `#${node.id}`;
    const tag = String(node.tagName || "").toLowerCase();
    if (!tag) return "";
    const nameAttr = node.getAttribute("name");
    if (nameAttr) return `${tag}[name="${nameAttr}"]`;
    return tag;
  }

  function evaluateNode(node, minContrast) {
    const results = [];
    const defaultResult = evaluateState(node, "default", minContrast);
    results.push(defaultResult);

    if (defaultResult && defaultResult.skipped) {
      return { results, decision: "pass" };
    }

    let focusTested = false;
    if (isFocusable(node) && typeof node.focus === "function") {
      try {
        node.focus({ preventScroll: true });
        if (document.activeElement === node) {
          if (typeof node.matches === "function") {
            focusTested = node.matches(":focus-visible") || node.matches(":focus");
          } else {
            focusTested = true;
          }
        }
      } catch (_) {
        focusTested = false;
      }
    }

    if (focusTested) {
      const focusResult = evaluateState(node, "focus", minContrast);
      results.push(focusResult);
      try {
        if (typeof node.blur === "function") node.blur();
      } catch (_) {}
    }

    const failing = results.find((result) => result && result.pass === false);
    if (failing) {
      return { results, decision: "fail", failingResult: failing };
    }

    return { results, decision: "pass" };
  }

  axe.configure({
    rules: [
      {
        id: RULE_ID,
        selector: CONTROL_SELECTOR,
        impact: "serious",
        tags: ["wcag2aa", "wcag22aa", "wcag1411", "custom"],
        any: [CHECK_ID],
        enabled: true,
        metadata: {
          description:
            "UI components must have at least 3:1 contrast against adjacent colors",
          help:
            "Ensure form controls and common ARIA widgets have 3:1 contrast for their outline, border, or fill",
          helpUrl: "https://www.w3.org/TR/WCAG22/#non-text-contrast",
          messages: {
            pass: "1.4.11 - Non-text Contrast - Pass",
            fail: "1.4.11 - Non-text Contrast - Fail"
          }
        }
      }
    ],
    checks: [
      {
        id: CHECK_ID,
        options: {
          minContrast: DEFAULT_MIN_CONTRAST
        },
        evaluate: function (node, options) {
          const minContrast =
            options && Number.isFinite(options.minContrast)
              ? options.minContrast
              : DEFAULT_MIN_CONTRAST;

          const evaluation = evaluateNode(node, minContrast);

          if (evaluation.decision === "pass") {
            return true;
          }

          const failingResult = evaluation.failingResult;
          const selector = getStableSelector(node);

          this.data = {
            reason: `Boundary contrast ${failingResult.ratio.toFixed(2)} is below ${minContrast}:1 in ${failingResult.state} state using ${failingResult.boundaryType}.`,
            ratio: Number(failingResult.ratio.toFixed(2)),
            minContrast,
            state: failingResult.state,
            boundaryType: failingResult.boundaryType,
            testerDebug: buildTesterDebug({
              ...failingResult,
              selector
            }, minContrast),
            engineDebug: buildEngineDebug(
              { ...failingResult, selector },
              failingResult.backgroundStack,
              failingResult.compositingSteps
            ),
            stateResults: evaluation.results
              .filter((result) => result && !result.skipped)
              .map((result) => ({
                state: result.state,
                ratio: result.ratio !== null ? Number(result.ratio.toFixed(2)) : null,
                boundaryType: result.boundaryType,
                boundaryColor: toRgbaString(result.boundaryColor),
                backgroundColor: toRgbaString(result.backgroundColor),
                effectiveComponentColor: toRgbaString(result.effectiveComponentColor)
              }))
          };
          try {
            node.__nonTextContrastDebug = this.data;
          } catch (_) {
            // ignore DOM write failures
          }

          return false;
        },
        metadata: {
          impact: "serious",
          messages: {
            pass:
              "1.4.11 - Non-text Contrast - component boundary contrast >= 3:1 - Pass",
            fail:
              "1.4.11 - Non-text Contrast - component boundary contrast < 3:1 - Fail"
          }
        }
      }
    ]
  });

  console.log("[AXE_CUSTOM_RULE] sc-1411-non-text-contrast loaded");
})();
